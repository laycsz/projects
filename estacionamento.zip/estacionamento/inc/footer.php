<footer class=" text-center text-lg-start">
  <svg class="svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
    <path fill="#280B39" fill-opacity="1" d="M0,128L40,128C80,128,160,128,240,106.7C320,85,400,43,480,58.7C560,75,640,149,720,160C800,171,880,117,960,80C1040,43,1120,21,1200,16C1280,11,1360,21,1400,26.7L1440,32L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z"></path>
  </svg>


  <!-- Copyright -->
  <div class="back p-3">
    © 2023 Layla Sousa

  </div>
  <!-- Copyright -->
</footer>
<style>
  footer {
    background-color: none;
    margin: 0;
  }
</style>
<script>
  import * as mdb from 'mdb-ui-kit'; // lib
  import {
    Input
  } from 'mdb-ui-kit';
</script>