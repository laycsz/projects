
<?php
   if (!defined('BASEURL'))

      define('BASEURL', 'http://: 192.168.0.45');
?>
